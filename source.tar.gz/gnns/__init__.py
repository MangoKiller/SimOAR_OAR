from .ba3 import Net as BA3Net
from .tr3 import Net as TR3Net
from .mnist import Net as MNISTNet
from .mutagenicity import Net as MutagenicityNet